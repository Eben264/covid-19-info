# Responsive Covid Website Built using HTML, CSS and JavaScript with Smooth Scrolling and Reveal Animations.

## [Watch it on youtube](https://youtu.be/HdvkIjhTUjM)

Don't forget to join the channel for more videos like this.
[Kishan Sheth](https://www.youtube.com/channel/UCDT8sIFy3pW8LT6SAbe8xtQ)
